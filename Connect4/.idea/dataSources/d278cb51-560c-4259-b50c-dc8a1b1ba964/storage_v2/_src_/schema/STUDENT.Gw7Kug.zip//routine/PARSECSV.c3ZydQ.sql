create procedure parseCSV(queryy IN varchar2) as
   v_fisier UTL_FILE.FILE_TYPE;
   v_cursor_id INTEGER;
   v_ok INTEGER;
   v_id int;
   v_nume varchar2(30);
   v_text VARCHAR2(100);
begin
  v_fisier:=UTL_FILE.FOPEN('MYDIR','parsecsv.csv','W');
  v_cursor_id := DBMS_SQL.OPEN_CURSOR;
  DBMS_SQL.PARSE(v_cursor_id, queryy, DBMS_SQL.NATIVE);
  DBMS_SQL.DEFINE_COLUMN(v_cursor_id, 1, v_id); 
  DBMS_SQL.DEFINE_COLUMN(v_cursor_id, 2, v_nume,30);  
  v_ok := DBMS_SQL.EXECUTE(v_cursor_id);

  LOOP 
     IF DBMS_SQL.FETCH_ROWS(v_cursor_id)>0 THEN 
         DBMS_SQL.COLUMN_VALUE(v_cursor_id, 1, v_id); 
         DBMS_SQL.COLUMN_VALUE(v_cursor_id, 2, v_nume); 
         v_text := v_id || ',' || v_nume || ',';
         UTL_FILE.PUTF(v_fisier,v_text);
      ELSE 
        EXIT; 
      END IF; 
  END LOOP;   
  DBMS_SQL.CLOSE_CURSOR(v_cursor_id);
  UTL_FILE.FCLOSE(v_fisier);
end;
/

