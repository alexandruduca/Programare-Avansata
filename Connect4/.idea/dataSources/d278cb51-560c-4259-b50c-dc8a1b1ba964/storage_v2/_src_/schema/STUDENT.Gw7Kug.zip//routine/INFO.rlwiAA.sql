create PROCEDURE info AS
    count_funct number;
    count_proced number;
    nr_lines number;
    determ varchar2(10);
BEGIN 

    SELECT COUNT(DISTINCT NAME)INTO count_proced FROM USER_SOURCE WHERE TYPE='PROCEDURE';
    SELECT COUNT(DISTINCT NAME)INTO count_funct FROM USER_SOURCE WHERE TYPE='FUNCTION';
    DBMS_OUTPUT.PUT_LINE('Number of functions: ' || count_funct);
    DBMS_OUTPUT.PUT_LINE('Number of procedures: ' || count_proced);


    FOR v_obj IN ( SELECT OBJECT_NAME, OBJECT_TYPE FROM USER_OBJECTS ) LOOP
       IF ( v_obj.OBJECT_TYPE = 'FUNCTION') THEN
                 SELECT COUNT(NAME)INTO nr_lines FROM USER_SOURCE WHERE TYPE='FUNCTION' AND NAME=UPPER(v_obj.OBJECT_NAME);
                 DBMS_OUTPUT.PUT_LINE('Function name: ' || v_obj.OBJECT_NAME);
                 DBMS_OUTPUT.PUT_LINE('Number of lines: ' || nr_lines);
                 DBMS_OUTPUT.PUT_LINE(' ');
        ELSIF ( v_obj.OBJECT_TYPE = 'PROCEDURE') THEN
                 SELECT COUNT(NAME)INTO nr_lines FROM USER_SOURCE WHERE TYPE='PROCEDURE' AND NAME=UPPER(v_obj.OBJECT_NAME);
                 DBMS_OUTPUT.PUT_LINE('Procedure name: ' || v_obj.OBJECT_NAME);
                 DBMS_OUTPUT.PUT_LINE('Number of lines: ' || nr_lines);
                 SELECT DETERMINISTIC INTO determ FROM USER_PROCEDURES WHERE OBJECT_NAME=UPPER(v_obj.OBJECT_NAME);
                 DBMS_OUTPUT.PUT_LINE(determ);
                 DBMS_OUTPUT.PUT_LINE(' ');
        END IF;
    END LOOP;

END;
/

