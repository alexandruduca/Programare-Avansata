create FUNCTION test (p_query VARCHAR2, p_tab VARCHAR2)
RETURN VARCHAR2 AS
bol BOOLEAN := true;
v_mesaj VARCHAR2(50);
v_cursor_id NUMBER;
v_ok NUMBER;
v_rec_tab DBMS_SQL.DESC_TAB;
v_nr_col NUMBER;
v_total_coloane NUMBER; 
v_found NUMBER := -1;

BEGIN
v_cursor_id  := DBMS_SQL.OPEN_CURSOR;
DBMS_SQL.PARSE(v_cursor_id , 'SELECT column_name FROM user_tab_cols WHERE table_name = '|| ''' ||p_tab||''', DBMS_SQL.NATIVE);
v_ok := DBMS_SQL.EXECUTE(v_cursor_id );
DBMS_SQL.DESCRIBE_COLUMNS(v_cursor_id, v_total_coloane, v_rec_tab);

v_nr_col := v_rec_tab.first;
  IF (v_nr_col IS NOT NULL) THEN
    LOOP
      v_found := INSTR(p_query ,TRIM(v_rec_tab(v_nr_col).col_name));
      IF v_found = -1 THEN
      EXIT;
      bol := false;
      END IF;
      v_found := -1;
      v_nr_col := v_rec_tab.next(v_nr_col);
      EXIT WHEN (v_nr_col IS NULL);
    END LOOP;
  END IF;
  DBMS_SQL.CLOSE_CURSOR(v_cursor_id);
  IF bol = false THEN
  v_mesaj := 'Nu';
  ELSE v_mesaj := 'Da';
  END IF;
  RETURN v_mesaj;
END;
/

